window.onload = function() {
    httpConnect('get', 'localhost:7777', 'import/pic_master', undefined, function (result) {
        datatable = $('#picMasterTbl').DataTable({
            data: result['data'],
            columns: [
                {   // Column : 0
                    data: "fg_no",
                    className: 'dt-center',
                    width: '33.33%'
                },
                {   // Column : 1
                    data: "sub_assy_name",
                    className: 'dt-center',
                    width: '33.33%'
                },
                {   // Column : 2
                    data: "pic_name",
                    className: 'dt-center',
                    width: '33.33%'
                }
            ],
            columnDefs: [
            ],
            "language": {
                "emptyTable": "No master data"
            },
            "scrollY": "100%",
            "scrollCollapse": true,
            "paging": false,
            "bInfo" : false,
            "ordering": false,
            "rowCallback": function(row, data) {
                // htmlUpload = `<img onclick="document.getElementById('`+data['fg_no']+`').click();" src="./images/img_upload.png" alt="upload" width="20" height="20">`
                // htmlUpload += `<input id="`+data['fg_no']+`" type="file" name="files" onchange="uploadPicture(this.files[0]);" />`;
                sub_assy_replace = data['sub_assy_name'].replace("'", "//")

                htmlUpload =    `<form method="post" enctype="multipart/form-data">`
                htmlUpload +=        `<img style="position:absolute; margin-top:-10px;" onclick="document.getElementById('`+data['fg_no']+`|`+sub_assy_replace+`').click();" src="./images/img_upload.png" alt="upload" width="20" height="20">`
                htmlUpload +=        `<input style="display:none;" type="file" id="`+data['fg_no']+'|'+sub_assy_replace+`" name="files[]" onchange="uploadPicture(this.id)"/>`
                // htmlUpload +=        `<input type="submit" value="Upload File" name="submit" onclick="uploadPicture()"/>`
                htmlUpload +=    `</form>`
                $('td:eq(2)', row).html(htmlUpload);
            }
        });
    },
    function (error) {
        console.log(error);
    });
    
    readCSVFile('csvInput', 'picMasterTbl');
}

function readCSVFile (elementID, tableID) {
    console.log('readCSVFile');
    var fileInput = document.getElementById(elementID),
    readFile = function () {
        var reader = new FileReader();
        reader.onload = function () {
            // document.getElementById('out').innerHTML = reader.result;
            csvDataObj = $.csv.toObjects(reader.result);
            csvDataObj = { ...csvDataObj };
            
            httpConnect('post', 'localhost:7777', 'import/csv', csvDataObj, function (result) {
                genDataTable(tableID, result['data']);
            },
            function (error) {
                console.log(error);
            });
        };
        // start reading the file. When it is done, calls the onload event defined above.
        reader.readAsText(fileInput.files[0]);
    };
    if (fileInput){
        fileInput.addEventListener('change', readFile, false);
    }
}

function genDataTable (tableID, datas) {
    datatable.clear().rows.add(datas).draw();
    // inputCSVfile(datas, function (result) {
    //     datatable.clear().rows.add(result).draw();
    // });
}

//* import file CSV
function inputCSVfile(allText, callback) {
    var allTextLines = allText.split(/\r\n|\n/);
    var headers = allTextLines[0].split(',');
    var datas = [];
    for (var i=1; i<allTextLines.length; i++) {
        var data = allTextLines[i].split(',');
        if (data.length == headers.length) {
            var temp = new Object;
            for (var j=0; j<headers.length; j++) {
                temp[headers[j]] = data[j];
            }
            datas.push(temp);
        }
    }
    callback(datas);
}

function uploadPicture(inputId) {
    const url = "upload.php";
    const form = document.querySelector('form');

    form.addEventListener('change', e => {
        e.preventDefault();

        const files = document.querySelector('[id="'+inputId+'"]').files;
        const formData = new FormData();
        for (let i = 0; i < files.length; i++) {
            files[i].id = inputId;
            let file = files[i];
            
            formData.append('files[]', file);
            formData.append('id[]', inputId);
        }
        console.log(formData);
        httpConnectPhoto('post', 'localhost:7777', 'import/upload', formData, function (result) {
            console.log(result);
        });
    })
}

function httpConnect (type, IPAddress, pathURL, data, callbackSuccess, callbackError) {
    if(localStorage.getItem('hostname')) {
        IPAddress = localStorage.getItem('hostname');
    }
    console.log(IPAddress);
    $.ajax({
        url: 'http://'+ IPAddress +'/api/v1/'+ pathURL,
        type: type,
        data: data,
        async: false,
        dataType: "json",
        timeout: 5000,
        success: function(result) {
            callbackSuccess(result);
        },
        error: function(result) {
            callbackError;
        }
    })
}


function httpConnectPhoto (type, IPAddress, pathURL, data, callbackSuccess, callbackError) {
    if(localStorage.getItem('hostname')) {
        IPAddress = localStorage.getItem('hostname');
    }
    $.ajax({
        url: 'http://'+ IPAddress +'/api/v1/'+ pathURL,
        type: type,
        data: data,
        async: false,
        processData: false,
        contentType: false,
        dataType: "json",
        timeout: 5000,
        success: function(result) {
            callbackSuccess(result);
        },
        error: function(result) {
            callbackError;
        }
    })
}