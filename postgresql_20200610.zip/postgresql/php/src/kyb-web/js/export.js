window.onload = function() {
    httpConnect('get', 'localhost:7777', 'export/pic_master', undefined, function (result) {
        datatable = $('#picMasterTbl').DataTable({
            data: result['data'],
            columns: [
                {   // Column : 0
                    data: "fg_no",
                    className: 'dt-center'
                },
                {   // Column : 1
                    data: "sub_assy_name",
                    className: 'dt-center'
                },
                {   // Column : 2
                    data: "Detail",
                    className: 'dt-center',
                    defaultContent: "-" //<i>-</i>
                },
                {   // Column : 3
                    data: "Summary",
                    className: 'dt-center',
                    defaultContent: "-" //<i>-</i>
                },
            ],
            columnDefs: [
            ],
            "language": {
                "emptyTable": "No master data"
            },
            "scrollY": "100%",
            "scrollCollapse": true,
            "paging": false,
            "bInfo" : false,
            "ordering": false,
            "rowCallback": function(row, data) {
                id = data['fg_no']+'|'+data['sub_assy_name']
                // htmlDownload = `<img id="`+id+`" src="./images/img_download.png" alt="download" width="20" height="20">`
                // $('td:eq(2)', row).html(htmlDownload);

                htmlDetail = `<img id="`+id+`" onclick="outputCSVfile(this.id, 'detail')" src="./images/img_download.png" alt="download" width="20" height="20">`
                $('td:eq(2)', row).html(htmlDetail);

                htmlSummary = `<img id="`+id+`" onclick="outputCSVfile(this.id, 'summary')" src="./images/img_download.png" alt="download" width="20" height="20">`
                $('td:eq(3)', row).html(htmlSummary);
            }
        });
    },
    function (error) {
        console.log(error);
    });
}

//* export CSV
function outputCSVfile(id, url) {
    var res = id.split("|");
    res = { ...res };
    this.httpConnect ('post', 'localhost:7777', 'export/'+url, res,
        function(result) {
            console.log(result);
            // DB not have data request
            if (result['data'].length == 0) {
                return 0;
            }

            arrayCSV = [];

            // add header array
            arrayCSV.push(Object.keys(result['data'][0]))

            dataLength = Object.keys(result['data']).length;
            for (let index = 0; index < dataLength; index++) {
                arrayCSV.push(Object.values(result['data'][index]))
            }
            let csvContent = "data:text/csv;charset=utf-8,";

            arrayCSV.forEach(function(rowArray) {
                let row = rowArray.join(",");
                csvContent += row + "\r\n";
            });
            
            var encodedUri = encodeURI(csvContent);
            var link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", id+'_'+url+".csv");
            document.body.appendChild(link);

            link.click();
        }, function (error) {
            console.log(error);
        }
    );
}