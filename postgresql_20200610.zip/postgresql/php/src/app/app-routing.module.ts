import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { LogInComponent } from './log-in/log-in.component';
import { SubAssyComponent } from './sub-assy/sub-assy.component';
import { ScanPartComponent } from './scan-part/scan-part.component';

const routes: Routes = [
  {path: 'login',component: LogInComponent},
  {path: 'sub-assy',component: SubAssyComponent},
  {path: 'scan-part',component: ScanPartComponent},
  { path: '', redirectTo: '/login', pathMatch: 'full'},
  { path: '**', component: PageNotFoundComponent }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
