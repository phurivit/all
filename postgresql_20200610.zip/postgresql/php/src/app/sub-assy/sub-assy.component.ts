import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import {Router} from '@angular/router';

import { SubAssyService } from './sub-assy.service';


interface Data {
  complete:any
};

@Component({
  selector: 'app-sub-assy',
  templateUrl: './sub-assy.component.html',
  styleUrls: ['./sub-assy.component.sass']
})


export class SubAssyComponent implements OnInit {

  sub_assy = new FormGroup({
    subAssyKey: new FormControl(''),
  });

  public staffID:string;
  public subAssyName:string;

  constructor(private router: Router, private subAssyService:SubAssyService) {}

  public emplData;
  ngOnInit(): void {
    this.emplData = JSON.parse(localStorage.getItem('emplData'));
    this.staffID = this.emplData.staff_id;
    this.subAssyName = this.emplData.sub_assy_name;
  }

  public subAssyKey;
  public OnSubmit() {
    let Sub_Assy_Key = this.sub_assy.value.subAssyKey;
    let data = {"staff_id":this.staffID,"sub_assy_name":this.subAssyName,"sub_assy_number":Sub_Assy_Key};
    this.subAssyKey = Sub_Assy_Key; 
    this.PostSubAssy(data);
  }
   
  PostSubAssy(data) {
    this.subAssyService.sendData(data).subscribe((data)=>{
      this.CheckSubAssyKey(data['data'].complete); 
    });
    // let complete:any;
    // if(data.sub_assy_number == '000'){  complete = true;  }
    // if(data.sub_assy_number == '123'){  complete = false;  }
    // if(data.sub_assy_number == '456'){  complete = 'finish';  }
    // this.CheckSubAssyKey(complete); 
  }
  
  public chkSubAssy:any;
  CheckSubAssyKey(complete){
    if(complete == true){ 
      this.chkSubAssy = true; 
      let setData = {'sub_assy_name':this.subAssyName,'staff_id':this.staffID, 'sub_assy_number':this.subAssyKey};
      localStorage.setItem('emplData', JSON.stringify(setData));
      this.router.navigate(['/scan-part']); 
    }
    if(complete == false){ 
        this.sub_assy.setValue({subAssyKey:""});
        this.chkSubAssy = false; 
      }
    if(complete == 'finish'){ 
      this.sub_assy.setValue({subAssyKey:""});
      this.chkSubAssy = 'finish'
    }
  };

  public focusFunction() {
    this.chkSubAssy = true; 
    this.sub_assy.setValue({subAssyKey:""});
  }
  
  public focusOutFunction() {
    this.chkSubAssy = true; 
    this.sub_assy.setValue({subAssyKey:""});
  }

 



}
