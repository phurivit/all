import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import {Router} from '@angular/router';

declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.sass']
})
export class LogInComponent implements OnInit {

  nameForm = new FormGroup({
    nameCode: new FormControl(''),
    type: new FormControl(''),
  });
  

  constructor(private router: Router) { }
  ngOnInit(): void {}


  public ckNameCode = true;
  public ckType = true;
  public ckNameCodeAndckType = true;

  public OnSubmit() {
    let data_login = this.nameForm.value;
    let dChexk = this.checkValiable(data_login)
    if(dChexk){
      let setData = {'sub_assy_name':data_login.type,'staff_id':data_login.nameCode};
      localStorage.setItem('emplData', JSON.stringify(setData));
      this.router.navigate(['/sub-assy']);
    }
  };

  checkValiable(data_login) {
    if(data_login.nameCode !=="" && data_login.type !==""){
      return true;
    }else{
      if(data_login.nameCode =="" && data_login.type !==""){
        this.ckNameCode = false;
        this.ckType = true;
        this.ckNameCodeAndckType = true;
      }
      if(data_login.type =="" && data_login.nameCode !==""){
        this.ckNameCode = true;
        this.ckType = false;
        this.ckNameCodeAndckType = true;
      }
      if(data_login.nameCode =="" && data_login.type ==""){
        this.ckNameCodeAndckType = false;
        this.ckNameCode = true;
        this.ckType = true;
      }
    }
  };

  

}
