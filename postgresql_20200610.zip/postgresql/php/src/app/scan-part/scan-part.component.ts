import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

import { ScanPartService } from './scan-part.service';
import { timer,from } from 'rxjs';

@Component({
  selector: 'app-scan-part',
  templateUrl: './scan-part.component.html',
  styleUrls: ['./scan-part.component.sass']
})
export class ScanPartComponent implements OnInit {


  partForm = new FormGroup({
    partNumber: new FormControl(''),
  });
  passForm = new FormGroup({
    OwnPassword: new FormControl(''),
  });

  public staffID:string;
  constructor(private scanPartService:ScanPartService) { }

  public DetailSubAssy:any;

  public emplData:any;
  ngOnInit(): void {
    this.emplData = JSON.parse(localStorage.getItem('emplData'));
    this.staffID = this.emplData.staff_id;
    this.getDetailSubAssy(this.emplData.sub_assy_number,this.emplData.sub_assy_name);
    // this.checkSubAssyPartNumber(485100 ,'A0343-72023','Piston ass\'y','48510-0A040');
    timer(1000).subscribe(() => { 
      this.checkSubAssyPartNumber(this.staffID ,this.emplData.sub_assy_number,this.emplData.sub_assy_name,this.DetailSubAssy.fg_number);
     });
    // this.checkContinue(this.emplData.sub_assy_number,this.emplData.sub_assy_name);
  }


 
  getDetailSubAssy(subAssyNumber,subAssyName){
    let data = { 'sub_assy_number':subAssyNumber, 'sub_assy_name':subAssyName};
    this.scanPartService.servDetailSubAssy(data).subscribe((res)=>{
      this.DetailSubAssy = res.data;
    });
  };

checkContinue(subAssyNumber,subAssyName){
    let data = { 'sub_assy_number':subAssyNumber, 'sub_assy_name':subAssyName};
    this.scanPartService.servDetailSubAssy(data).subscribe((res)=>{
      let fg_number = res.data.fg_number;
      this.checkSubAssyPartNumber(this.staffID ,this.emplData.sub_assy_number,this.emplData.sub_assy_name,fg_number);
    });
  };

  public DetailPartNumber:any;
  checkSubAssyPartNumber(staffID,sub_assy_number,sub_assy_name,fg_number) {
    let data = { 'staff_id':staffID,'sub_assy_number':sub_assy_number,'sub_assy_name':sub_assy_name,'fg_number':fg_number };
    this.scanPartService.servCheckSubAssyPartNumber(data).subscribe((res)=>{
      this.DetailPartNumber = res.data;
    });
  }

  public OnSubmitPartNumber() {
    let partNumber = this.partForm.value.partNumber;
    let data = {
        'staff_id': this.staffID,
        'part_number':partNumber,
        'fg_number':this.DetailSubAssy.fg_number,
        'sub_assy_name':this.emplData.sub_assy_name,
        'sub_assy_number':this.DetailSubAssy.sub_assy_number
       };
    this.scanPartService.servPostPartNumber(data).subscribe((res)=>{
      this.DetailPartNumber = res.data;
    });
    // console.log(data);
    // let res = {
    //   'part_number':"kfdjgsfdjgdfhg",
    //   'code_loc':"P-2-1",
    //   'part_name': "value",
    //   'qty':"1",
    //   'seq_no':9,
    //   'complete':false
    // };
    // this.DetailPartNumber = res;
  };


  public OnSubmitCheckPass() {
    console.log(this.passForm.value.OwnPassword);
    this.checkPass(this.passForm.value.OwnPassword);
  };

  public passCode = false;
  checkPass(password) {
      let pass = '150620';
      if(password === pass){
        let data = { 
          'staff_id':this.staffID,
          'sub_assy_number':this.DetailSubAssy.sub_assy_number,
          'sub_assy_name':this.emplData.sub_assy_name,
          'fg_number':this.DetailSubAssy.fg_number 
        };
        this.scanPartService.servPass(data).subscribe((res)=>{
          this.DetailPartNumber = res.data;
        });
        //   let res = {
        //     'part_number':"",
        //     'code_loc':"P-2-1",
        //     'part_name': "value",
        //     'qty':"1",
        //     'seq_no':9,
        //     'complete':true
        //   }
        // // this.DetailPartNumber.complete = true;
        // this.DetailPartNumber = res;
      }else{
        this.passCode = true;
      } 
  }

}
