import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ScanPartService {


  public url:string = "http://localhost:7777/api/v1/";
  constructor(private http: HttpClient) { }

  public servDetailSubAssy(data){
    return this.http.post(this.url+'kyb/details', data);
  }

  public servCheckSubAssyPartNumber(data){
    console.log(data);
    return this.http.post(this.url+'kyb/safe', data);
  }

  public servPostPartNumber(data){
    return this.http.post(this.url+'kyb/submit', data);
  };

  public servPass(data){
    return this.http.post(this.url+'kyb/proceed', data);
  };


}
