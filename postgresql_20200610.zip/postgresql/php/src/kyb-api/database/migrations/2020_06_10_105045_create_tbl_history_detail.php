<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblHistoryDetail extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_history_detail', function (Blueprint $table) {
           // $table->increments('id');
           // $table->timestamps();
            $table->integer('staff_id')->nullable();
            $table->timestamp('time')->nullable();
            $table->string('sub_assy_no')->nullable();
            $table->string('fg_no')->nullable();
            $table->string('sub_assy_name')->nullable();
            $table->string('model')->nullable();
            $table->string('line')->nullable();
            $table->integer('seq_no')->nullable();
            $table->string('part_no')->nullable();
            $table->string('part_name')->nullable();
            $table->string('code')->nullable();
            $table->integer('qty')->nullable();
            $table->string('result')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_history_detail');
    }
}
