<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblItemMasterData extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_item_master_data', function (Blueprint $table) {
            //$table->increments('id');
            //$table->timestamps();
            $table->string('sub_assy_no')->nullable();
            $table->string('fg_no')->nullable();
            $table->string('sub_assy_name')->nullable();
            $table->string('model')->nullable();
            $table->string('line')->nullable();
            $table->integer('seq_no')->nullable();
            $table->string('part_no')->nullable();
            $table->string('part_name')->nullable();
            $table->string('code')->nullable();
            $table->integer('qty')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_item_master_data');
    }
}
