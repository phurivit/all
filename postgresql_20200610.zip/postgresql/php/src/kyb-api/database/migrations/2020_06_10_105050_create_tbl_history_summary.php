<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblHistorySummary extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_history_summary', function (Blueprint $table) {
           // $table->increments('id');
           // $table->timestamps();
            $table->bigInteger('staff_id')->nullable();
            $table->timestamp('time_scan')->nullable();
            $table->string('sub_assy_no')->nullable();
            $table->string('fg_no')->nullable();
            $table->string('sub_assy_name')->nullable();
            $table->string('model')->nullable();
            $table->string('line')->nullable();
            $table->string('status')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_history_summary');
    }
}
