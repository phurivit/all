<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Monolog\Logger;
use Monolog\Formatter\LineFormatter;
use Monolog\Handler\RotatingFileHandler;

class LogServiceProvider extends ServiceProvider
{
    public function boot()
    {
        app('Psr\Log\LoggerInterface')->setHandlers($this->getRotatingLogHandler());
    }

    public function getRotatingLogHandler($maxFiles = 10)
    {
        $handlers = [];
        // config debug log
        $debug_handler = (new RotatingFileHandler(storage_path('logs/lumen-debug.log'), $maxFiles, Logger::DEBUG))->setFormatter(new LineFormatter(null, null, true, true));
        $debug_handler->setFilenameFormat('{filename}-{date}','Y-m-d');
        // config debug log
        // $info_handler = (new RotatingFileHandler(storage_path('logs/lumen-info.log'), $maxFiles, Logger::INFO))->setFormatter(new LineFormatter(null, null, true, true));
        // $info_handler->setFilenameFormat('{filename}-{date}','Y-m-d');
        // add to handlers
        $handlers[] = $debug_handler;
        // $handlers[] = $info_handler;
        return $handlers;
    }

    public function register()
    {
        // 
    }
}