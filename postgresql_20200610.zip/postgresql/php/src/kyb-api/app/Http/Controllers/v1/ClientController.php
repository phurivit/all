<?php

namespace App\Http\Controllers\v1;

use App\Services\v1\DebugLogService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class ClientController extends Controller{

    // check $request's sub assy number in database
    public function checkSubAssyNum(Request $request)
    {
        $result = app('db')
            ->table('tbl_item_master_data')
            ->where('sub_assy_no', $request->input('sub_assy_number'))
            ->where('sub_assy_name', $request->input('sub_assy_name'))
            ->get();

        $resultSummary = app('db')
            ->table('tbl_history_summary')
            ->where('sub_assy_no', $request->input('sub_assy_number'))
            ->where('sub_assy_name', $request->input('sub_assy_name'))
            ->get();

        if (sizeof($resultSummary) > 0) {
            $return = ['complete' => 'finish'];

            return $this->json(["data" => $return], 200);
        }

        if (sizeof($result) > 0) {
            $return = ['complete' => true];
        } else {
            $return = ['complete' => false];
        }

        return $this->json(["data" => $return], 200);
    }


    public function getDetails(Request $request)
    {
        $itemMaster = app('db')
            ->table('tbl_item_master_data')
            ->select('fg_no as fg_number', 'sub_assy_no as sub_assy_number', 'seq_no')
            ->where('sub_assy_no', $request->input('sub_assy_number'))
            ->where('sub_assy_name', $request->input('sub_assy_name'))
            ->orderBy('seq_no', 'asc')
            ->first();
        error_log(print_r($itemMaster, TRUE));  
        error_log(print_r($itemMaster->fg_number, TRUE)); 
        error_log(print_r($request->input('sub_assy_name'), TRUE));
        
        if (sizeof($itemMaster) > 0) {
            // get picture name
            error_log(print_r('getDetails1 is called', TRUE)); 

            $picName = app('db')->table('tbl_picture_master_data')
                ->where('sub_assy_name', $request->input('sub_assy_name'))
                ->where('fg_no', $itemMaster->fg_number)
                ->get()
                ->pluck("pic_name")
                ->last();

            // get path dir app
            $pathSplit = explode("/", base_path('uploads'));
            $pathSearch = array_search('kyb-api', $pathSplit);
            $pathPhoto = 'http://localhost';
            for ($i=$pathSearch; $i < sizeof($pathSplit); $i++) { 
                $pathPhoto = $pathPhoto.'/'.$pathSplit[$i];
            }
            $pathPhoto = $pathPhoto.'/'.$picName;
            
            $result = [
                "img_src" => $pathPhoto,
                "sub_assy_number" => $itemMaster->sub_assy_number,
                "fg_number" => $itemMaster->fg_number,
                "seq_no" => $itemMaster->seq_no,
            ];

            return $this->json(["data" => $result], 200);
        } else {
            // return error
            return $this->json(["data" => ["complete" => false]], 200);
        }
    }

    public function getRecentDetails(Request $request)
    {
        $historyDetail = app('db')
            ->table('tbl_history_detail')
            ->select('part_no as part_number', 'code as code_loc', 'part_name', 'qty', 'seq_no')
            ->where('staff_id', $request->input('staff_id'))
            ->where('sub_assy_no', $request->input('sub_assy_number'))
            ->where('sub_assy_name', $request->input('sub_assy_name'))
            ->where('fg_no', $request->input('fg_number'))
            ->where('result', 'OK')
            ->orderBy('seq_no', 'asc')
            ->get()
            ->last();

            // return data if get data query
        if (isset($historyDetail)) {
            $historyDetail->complete = true;
            return $this->json(["data" => $historyDetail], 200);
        } else {
            return $this->json(["data" => ["complete" => true]], 200);
        }
    }

    public function checkState(Request $request)
    {
        $resultSummary = app('db')
            ->table('tbl_history_summary')
            ->where('sub_assy_no', $request->input('sub_assy_number'))
            ->where('sub_assy_name', $request->input('sub_assy_name'))
            ->get();

        if (sizeof($resultSummary) > 0) {
            $return = ['complete' => 'finish'];

            return $this->json(["data" => $return], 200);
        }

        $historyDetail = app('db')
            ->table('tbl_history_detail')
            ->select('part_no as part_number', 'code as code_loc', 'part_name', 'qty', 'seq_no', 'result')
            ->where('staff_id', $request->input('staff_id'))
            ->where('sub_assy_no', $request->input('sub_assy_number'))
            ->where('sub_assy_name', $request->input('sub_assy_name'))
            ->where('fg_no', $request->input('fg_number'))
            ->get()
            ->last();
            
        if (isset($historyDetail)) {
            if ($historyDetail->result == 'OK') {
                $historyDetail->complete = true;
                return $this->json(["data" => $historyDetail], 200);
            } else {
                $error = [
                    "complete" => false
                ];
                if (strpos(strtolower($historyDetail->result), 'seq')) {
                    $error['desc'] = 'seq';
                } else if (strpos(strtolower($historyDetail->result), 'part')) {
                    $error['desc'] = 'part';
                }
                return $this->json(["data" => $error], 200);
            }
        } else {
            // return false if not get data
            return $this->json(["data" => ["complete" => true]], 200);
        }
    }

    public function submitPartNumber(Request $request)
    {
        $itemMaster = app('db')->table('tbl_item_master_data')
            ->where('fg_no', $request->input('fg_number'))
            ->where('part_no', $request->input('part_number'))
            ->where('sub_assy_no', $request->input('sub_assy_number'))
            ->where('sub_assy_name', $request->input('sub_assy_name'))
            ->orderBy('seq_no', 'asc')
            ->first();

        $maxSeqNum = app('db')->table('tbl_item_master_data')
            ->where('sub_assy_no', $request->input('sub_assy_number'))
            ->where('sub_assy_name', $request->input('sub_assy_name'))
            ->orderBy('seq_no', 'asc')
            ->get()
            ->pluck('seq_no')
            ->last();

        $lastSeqNoSubmit = app('db')->table('tbl_history_detail')
            ->where('staff_id', $request->input('staff_id'))
            ->where('sub_assy_no', $request->input('sub_assy_number'))
            ->where('sub_assy_name', $request->input('sub_assy_name'))
            ->where('result', 'OK')
            ->orderBy('seq_no', 'asc')
            ->get()
            ->pluck('seq_no')
            ->last();

        if(!isset($lastSeqNoSubmit)) {
            $lastSeqNoSubmit = 0;
        }
        
        $currentDateTime = date("d/m/Y H:i:s");

        if (sizeof($itemMaster) > 0 && ($lastSeqNoSubmit+1 == $itemMaster->seq_no)) {

            $insertDetail = [
                "staff_id" => $request->input('staff_id'),
                "time" => $currentDateTime,
                "sub_assy_no" => $itemMaster->sub_assy_no,
                "fg_no" =>  $itemMaster->fg_no,
                "sub_assy_name" =>  $itemMaster->sub_assy_name,
                "model" =>  $itemMaster->model,
                "line" =>  $itemMaster->line,
                "seq_no" =>  $itemMaster->seq_no,
                "part_no" =>  $itemMaster->part_no,
                "part_name" =>  $itemMaster->part_name,
                "code" =>  $itemMaster->code,
                "qty" =>  $itemMaster->qty,
                "result" => "OK"
            ];

            app('db')->table('tbl_history_detail')
                ->insert($insertDetail);
            
            $result = [
                "part_number" =>  $itemMaster->part_no,
                "code_loc" =>  $itemMaster->code,
                "part_name" =>  $itemMaster->part_name,
                "qty" =>  $itemMaster->qty,
                "seq_no" =>  $itemMaster->seq_no,
            ];

            if ($itemMaster->seq_no < $maxSeqNum) {
                $result['complete'] = true;
            } else if ($itemMaster->seq_no == $maxSeqNum) {
                $insertSummary = [
                    "staff_id" => $request->input('staff_id'),
                    "time_scan" => $currentDateTime,
                    "sub_assy_no" => $itemMaster->sub_assy_no,
                    "fg_no" =>  $itemMaster->fg_no,
                    "sub_assy_name" =>  $itemMaster->sub_assy_name,
                    "model" =>  $itemMaster->model,
                    "line" =>  $itemMaster->line,
                    "status" => "OK"
                ];

                app('db')->table('tbl_history_summary')
                    ->insert($insertSummary);

                $result['complete'] = 'success';
            }

            return $this->json(["data" => $result], 200);
        } else {
            $error = [
                "complete" => false
            ];
            if (!isset($itemMaster)) {
                $insertDetail = [
                    "staff_id" => $request->input('staff_id'),
                    "time" => $currentDateTime,
                    "sub_assy_no" => NULL,
                    "fg_no" =>  NULL,
                    "sub_assy_name" =>  NULL,
                    "model" =>  NULL,
                    "line" =>  NULL,
                    "seq_no" =>  NULL,
                    "part_no" =>  $request->input('part_number'),
                    "part_name" =>  NULL,
                    "code" =>  NULL,
                    "qty" =>  NULL,
                    "result" => "Wrong part number"
                ];

                $error['desc'] = 'part';
            } else {
                $insertDetail = [
                    "staff_id" => $request->input('staff_id'),
                    "time" => $currentDateTime,
                    "sub_assy_no" => $itemMaster->sub_assy_no,
                    "fg_no" =>  $itemMaster->fg_no,
                    "sub_assy_name" =>  $itemMaster->sub_assy_name,
                    "model" =>  $itemMaster->model,
                    "line" =>  $itemMaster->line,
                    "seq_no" =>  $itemMaster->seq_no,
                    "part_no" =>  $itemMaster->part_no,
                    "part_name" =>  $itemMaster->part_name,
                    "code" =>  $itemMaster->code,
                    "qty" =>  $itemMaster->qty,
                    "result" => "Wrong Seq.no"
                ];

                $error['desc'] = 'seq';
            }

            app('db')->table('tbl_history_detail')
            ->insert($insertDetail);

            return $this->json(["data" => $error], 200);
        }
    }
}