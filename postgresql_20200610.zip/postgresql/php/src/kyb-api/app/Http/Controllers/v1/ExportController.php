<?php

namespace App\Http\Controllers\v1;

use App\Services\v1\DebugLogService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class ExportController extends Controller{

    public function queryPicMasterList ()
    {
        $result = app('db')->table('tbl_picture_master_data')
            ->select('fg_no', 'sub_assy_name')
            ->get();

        return $result;
    }

    public function getPicMasterList ()
    {
        $result = $this->queryPicMasterList();

        return $this->json(["data" => $result], 200);
    }

    public function getHistoryDetail(Request $request)
    {
        $data = $request->all();
        $fgNum = $data[0];
        $subAssyName = $data[1];

        $result = app('db')->table('tbl_history_detail')
            ->where('fg_no', $fgNum)
            ->where('sub_assy_name', $subAssyName)
            ->get();

        return $this->json(["data" => $result], 200);
    }

    public function getHistorySummary(Request $request)
    {
        $data = $request->all();
        $fgNum = $data[0];
        $subAssyName = $data[1];

        $result = app('db')->table('tbl_history_summary')
            ->where('fg_no', $fgNum)
            ->where('sub_assy_name', $subAssyName)
            ->get();

        return $this->json(["data" => $result], 200);
    }
}