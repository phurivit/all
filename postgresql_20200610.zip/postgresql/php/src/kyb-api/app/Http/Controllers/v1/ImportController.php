<?php

namespace App\Http\Controllers\v1;

use App\Services\v1\DebugLogService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Log;

class ImportController extends Controller{

    public function queryPicMasterList ()
    {
        $result = app('db')->table('tbl_picture_master_data')
            ->get();

        return $result;
    }

    public function getPicMasterList ()
    {
        $result = $this->queryPicMasterList();

        return $this->json(["data" => $result], 200);
    }

    public function importCSV(Request $request)
    {
        $data = $request->all();
        $data = json_decode(json_encode($data), true);
        $dataAssy = array_column($data, 'Sub assy name');
        $dataFG = array_column($data, 'FG number');
        // $dataColumn = array_column($data, 'Sub assy name', 'FG number');

        // delete file in folder
        $files = glob('../uploads/*'); // get all file names
        foreach($files as $file){ // iterate files
            if(is_file($file)){
                unlink($file); // delete file
            }
        }

        // clear all data
        $this->clearDataDB();

        // check data in tbl_picturemaster if not exist add new one.
        for ($i=0; $i < sizeof($data); $i++) { 
            $checkExist = app('db')->table('tbl_picture_master_data')
                ->where("fg_no", $dataFG[$i])
                ->where("sub_assy_name", $dataAssy[$i])
                ->get();

            if (sizeof($checkExist) == 0) {
                app('db')->table('tbl_picture_master_data')
                    ->insert([
                        "fg_no" => $dataFG[$i],
                        "sub_assy_name" => $dataAssy[$i]
                    ]);
            }
        }

        for ($i=0; $i < sizeof($data); $i++) {
            $getItemMaster = app('db')->table('tbl_item_master_data')
                ->where('part_no', $data[$i]['Part number'])
                ->where('fg_no', $data[$i]['FG number'])
                ->where('sub_assy_name', $data[$i]['Sub assy name'])
                ->get();

            if (sizeof($getItemMaster) == 0) {
                $addItem = [
                    "sub_assy_no" => $data[$i]['Sub assy no'],
                    "fg_no" => $data[$i]['FG number'],
                    "sub_assy_name" => $data[$i]['Sub assy name'],
                    "model" => $data[$i]['Model'],
                    "line" => $data[$i]['Line'],
                    "seq_no" => $data[$i]['Seq.no'],
                    "part_no" => $data[$i]['Part number'],
                    "part_name" => $data[$i]['Part name'],
                    "code" => $data[$i]['Code/Loc'],
                    "qty" => $data[$i]['Qty']
                ];

                app('db')->table('tbl_item_master_data')
                    ->insert($addItem);
            }
        }

        $result = $this->queryPicMasterList();

        return $this->json(["data" => $result], 200);
    }

    public function clearDataDB()
    {
        app('db')->table('tbl_item_master_data')
            ->truncate();

        app('db')->table('tbl_picture_master_data')
            ->truncate();

        app('db')->table('tbl_history_detail')
            ->truncate();

        app('db')->table('tbl_history_summary')
            ->truncate();
    }

    public function fileUpload(Request $request)
    {
        // var_dump($request->all());
        $data = $request->all();
        $idSplit = explode("|", $data['id'][0]);
        
        $fg_no = $idSplit[0];
        $sub_assy_name = str_replace("//","'",$idSplit[1]);
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_FILES['files'])) {
                $errors = [];
                $path = '../uploads/';
                // $extensions = ['jpg', 'jpeg', 'png', 'gif'];

                $all_files = count($_FILES['files']['tmp_name']);
        
                for ($i = 0; $i < $all_files; $i++) {
                    // $file_id = $_FILES['id'][$i];
                    $file_name = $_FILES['files']['name'][$i];
                    $file_tmp = $_FILES['files']['tmp_name'][$i];
                    $file_type = $_FILES['files']['type'][$i];
                    $file_size = $_FILES['files']['size'][$i];
                    // $file_ext = strtolower(end(explode('.', $_FILES['files']['name'][$i])));
                    $file = $path . $file_name;
                    // if (!in_array($file_ext, $extensions)) {
                    //     $errors[] = 'Extension not allowed: ' . $file_name . ' ' . $file_type;
                    // }
        
                    // if ($file_size > 2097152) {
                    //     $errors[] = 'File size exceeds limit: ' . $file_name . ' ' . $file_type;
                    // }
        
                    if (empty($errors)) {
                        move_uploaded_file($file_tmp, $file);

                        app('db')->table('tbl_picture_master_data')
                            ->where('fg_no', $fg_no)
                            ->where('sub_assy_name', $sub_assy_name)
                            ->update([
                                'pic_name' => $file_name
                            ]);
                    }
                }
        
                if ($errors) print_r($errors);
            }
        }

        // return $this->json(["data" => '$objectImg'], 200);
    }
}