<?php
    // Change above line to:
    $ip = $_SERVER['SERVER_ADDR'];
    
    echo $ip;
?>