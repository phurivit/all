<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblPictureMasterData extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_picture_master_data', function (Blueprint $table) {
            //$table->increments('id');
            //$table->timestamps();
            $table->string('fg_no')->nullable();
            $table->string('sub_assy_name')->nullable();
            $table->string('pic_name')->nullable();
            $table->string('sub_assy_no')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_picture_master_data');
    }
}
