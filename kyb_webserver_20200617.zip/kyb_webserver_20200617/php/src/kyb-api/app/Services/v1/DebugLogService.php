<?php
  
namespace App\Services\v1;

use Monolog\Logger;
use Monolog\Formatter\LineFormatter;
use Monolog\Handler\RotatingFileHandler;
use Monolog\Handler\StreamHandler;

class DebugLogService {
    
    private $log;

    public function __construct($channel="debug",$msg="",$var=null) 
    {
        $this->log = new Logger($channel);
        $debug_handler = (new RotatingFileHandler(storage_path("logs/$channel.log"), 3, Logger::DEBUG))->setFormatter(new LineFormatter(null, null, true, true));
        $debug_handler->setFilenameFormat('{filename}-{date}','Y-m-d');
        $this->log->pushHandler($debug_handler);
    }

    public function log($msg="",$var=null)
    {
        if ($var != null) {
            $this->log->debug($msg,$var);
        } else {
            $this->log->debug($msg);
        }
    }
}
