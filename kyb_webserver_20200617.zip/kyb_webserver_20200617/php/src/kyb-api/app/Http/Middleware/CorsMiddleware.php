<?php 

namespace App\Http\Middleware;
use Illuminate\Http\Response;

class CorsMiddleware {
  public function handle($request, \Closure $next)
  {
     $response = $next($request);

    if ($request->getMethod() == 'OPTIONS' && $response->getStatusCode() == 405) 
    {
    	$response = new Response('OK');
    }

    $response->header('Access-Control-Allow-Methods', 'HEAD, GET, POST, PUT, PATCH, OPTIONS, DELETE');

    $response->header('Access-Control-Allow-Headers', $request->header('Access-Control-Request-Headers'));

    $response->header('Access-Control-Allow-Origin', '*');

    $response->header('Access-Control-Allow-Credentials', 'true');

    return $response;

  }
}

