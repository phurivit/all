<?php 
 
/* 
|-------------------------------------------------------------------------- 
| Application Routes 
|-------------------------------------------------------------------------- 
| 
| Here is where you can register all of the routes for an application. 
| It is a breeze. Simply tell Lumen the URIs it should respond to 
| and give it the Closure to call when that URI is requested. 
| 
*/ 
 
$version = 'v1';

$router->group(['prefix' => 'api/'.$version.'/import','namespace' => $version], function($router)
{
    $router->group(['middleware' => []], function($router)
    {
        $router->get('pic_master','ImportController@getPicMasterList');
        $router->post('csv','ImportController@importCSV');
        $router->post('upload','ImportController@fileUpload');
    });
});

$router->group(['prefix' => 'api/'.$version.'/export','namespace' => $version], function($router)
{
    $router->group(['middleware' => []], function($router)
    {
        $router->get('pic_master','ExportController@getPicMasterList');
        // $router->post('csv','ExportController@getHistoryTable');
        $router->post('detail','ExportController@getHistoryDetail');
        $router->post('summary','ExportController@getHistorySummary');
    });
});

$router->group(['prefix' => 'api/'.$version.'/kyb','namespace' => $version], function($router)
{
    $router->group(['middleware' => []], function($router)
    {
        $router->post('sub_assy','ClientController@checkSubAssyNum');
        $router->post('details','ClientController@getDetails');
        $router->post('proceed','ClientController@getRecentDetails');
        $router->post('safe','ClientController@checkState');
        $router->post('submit','ClientController@submitPartNumber');
    });
});