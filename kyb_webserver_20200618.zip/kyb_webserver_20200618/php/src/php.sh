cd /var/www/html/kyb-api
php -S 0.0.0.0:7777 -t public &
