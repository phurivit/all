<?php

namespace App\Http\Controllers\v1;

use App\Services\v1\DebugLogService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;

class ImportController extends Controller{

    public function queryPicMasterList ()
    {
        $result = app('db')->table('tbl_picture_master_data')
            ->orderBy('fg_no', 'asc')
            ->get();

        return $result;
    }

    public function getPicMasterList ()
    {
        $result = $this->queryPicMasterList();

        return $this->json(["data" => $result], 200);
    }

    public function importCSV(Request $request)
    {
        $data = $request->all();
        $data = json_decode(json_encode($data), true);
        $dataAssyName = array_column($data, 'Sub assy name');
        $dataAssyNum = array_column($data, 'Sub assy no');
        $dataFG = array_column($data, 'FG number');

        if (count(array_unique($dataAssyName)) === 1 && 
            count(array_unique($dataAssyNum)) === 1 && 
            count(array_unique($dataFG)) === 1) {
            $inputAssyName = array_unique($dataAssyName);
            $inputAssyNum = array_unique($dataAssyNum);
            $inputFG = array_unique($dataFG);

            $checkExist = app('db')->table('tbl_picture_master_data')
                ->where("sub_assy_name", $inputAssyName[0])
                ->where("sub_assy_no", $inputAssyNum[0])
                ->where("fg_no", $inputFG[0])
                ->get();

            if (sizeof($checkExist) == 0) {
                Schema::create("$inputAssyNum[0]_$inputAssyName[0]_csv", function(Blueprint $table) {
                    $table->string('sub_assy_no')->nullable();
                    $table->string('fg_no')->nullable();
                    $table->string('sub_assy_name')->nullable();
                    $table->string('model')->nullable();
                    $table->string('line')->nullable();
                    $table->bigInteger('seq_no')->nullable();
                    $table->string('part_no')->nullable();
                    $table->string('part_name')->nullable();
                    $table->string('code_loc')->nullable();
                    $table->bigInteger('qty')->nullable();
                });

                Schema::create("$inputAssyNum[0]_$inputAssyName[0]_detail", function(Blueprint $table) {
                    $table->string('staff_id')->nullable();
                    $table->string('time_scan')->nullable();
                    $table->string('sub_assy_no')->nullable();
                    $table->string('fg_no')->nullable();
                    $table->string('sub_assy_name')->nullable();
                    $table->string('model')->nullable();
                    $table->string('line')->nullable();
                    $table->bigInteger('seq_no')->nullable();
                    $table->string('part_no')->nullable();
                    $table->string('part_name')->nullable();
                    $table->string('code_loc')->nullable();
                    $table->bigInteger('qty')->nullable();
                    $table->string('result_scan')->nullable();
                });

                Schema::create("$inputAssyNum[0]_$inputAssyName[0]_summary", function(Blueprint $table) {
                    $table->string('staff_id')->nullable();
                    $table->string('time_scan')->nullable();
                    $table->string('sub_assy_no')->nullable();
                    $table->string('fg_no')->nullable();
                    $table->string('sub_assy_name')->nullable();
                    $table->string('model')->nullable();
                    $table->string('line')->nullable();
                    $table->string('status')->nullable();
                });

                app('db')->table('tbl_picture_master_data')
                    ->insert([
                        "sub_assy_name" => $inputAssyName[0],
                        "sub_assy_no" => $inputAssyNum[0],
                        "fg_no" => $inputFG[0]
                    ]);
                for ($i=0; $i < sizeof($data); $i++) {
                    $csvTable = app('db')->table("$inputAssyNum[0]_$inputAssyName[0]_csv")
                        ->where('part_no', $data[$i]['Part number'])
                        ->where('fg_no', $data[$i]['FG number'])
                        ->where('sub_assy_name', $data[$i]['Sub assy name'])
                        ->where('seq_no', $data[$i]['Seq.no'])
                        ->get();

                    if (sizeof($csvTable) == 0) {
                        $addItem = [
                            "sub_assy_no" => $data[$i]['Sub assy no'],
                            "fg_no" => $data[$i]['FG number'],
                            "sub_assy_name" => $data[$i]['Sub assy name'],
                            "model" => $data[$i]['Model'],
                            "line" => $data[$i]['Line'],
                            "seq_no" => $data[$i]['Seq.no'],
                            "part_no" => $data[$i]['Part number'],
                            "part_name" => $data[$i]['Part name'],
                            "code_loc" => $data[$i]['Code/Loc'],
                            "qty" => $data[$i]['Qty']
                        ];

                        app('db')->table("$inputAssyNum[0]_$inputAssyName[0]_csv")->insert($addItem);
                    }
                }
            } else {
                $this->clearDataDB("$inputAssyNum[0]_$inputAssyName[0]_csv");
                $this->clearDataDB("$inputAssyNum[0]_$inputAssyName[0]_detail");
                $this->clearDataDB("$inputAssyNum[0]_$inputAssyName[0]_summary");

                $picName = app('db')->table('tbl_picture_master_data')
                    ->where('sub_assy_name', $inputAssyName[0])
                    ->where('sub_assy_no', $inputAssyNum[0])
                    ->where('fg_no', $inputFG[0])
                    ->get()
                    ->pluck("pic_name")
                    ->last();

                $filePath = '../uploads/'.$picName;

                // delete image
                if (is_file($filePath)) {
                    unlink($filePath);
                }

                app('db')->table('tbl_picture_master_data')
                    ->where('sub_assy_name', $inputAssyName[0])
                    ->where('sub_assy_no', $inputAssyNum[0])
                    ->where('fg_no', $inputFG[0])
                    ->update([
                        'pic_name' => NULL
                    ]);

                for ($i=0; $i < sizeof($data); $i++) {
                    $csvTable = app('db')->table("$inputAssyNum[0]_$inputAssyName[0]_csv")
                        ->where('part_no', $data[$i]['Part number'])
                        ->where('fg_no', $data[$i]['FG number'])
                        ->where('sub_assy_name', $data[$i]['Sub assy name'])
                        ->where('seq_no', $data[$i]['Seq.no'])
                        ->get();

                    if (sizeof($csvTable) == 0) {
                        $addItem = [
                            "sub_assy_no" => $data[$i]['Sub assy no'],
                            "fg_no" => $data[$i]['FG number'],
                            "sub_assy_name" => $data[$i]['Sub assy name'],
                            "model" => $data[$i]['Model'],
                            "line" => $data[$i]['Line'],
                            "seq_no" => $data[$i]['Seq.no'],
                            "part_no" => $data[$i]['Part number'],
                            "part_name" => $data[$i]['Part name'],
                            "code_loc" => $data[$i]['Code/Loc'],
                            "qty" => $data[$i]['Qty']
                        ];

                        app('db')->table("$inputAssyNum[0]_$inputAssyName[0]_csv")->insert($addItem);
                    }
                }
            }
        }

        $result = $this->queryPicMasterList();

        return $this->json(["data" => $result], 200);
    }

    public function clearDataDB($tableName)
    {
        app('db')->table($tableName)->truncate();
    }

    public function fileUpload(Request $request)
    {
        $data = $request->all();
        $idSplit = explode("|", $data['id'][0]);
        
        $sub_assy_no = $idSplit[0];
        $sub_assy_name = str_replace("//","'",$idSplit[1]);
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_FILES['files'])) {
                $errors = [];
                $path = '../uploads/';

                $all_files = count($_FILES['files']['tmp_name']);
        
                for ($i = 0; $i < $all_files; $i++) {
                    $file_name = $_FILES['files']['name'][$i];
                    $file_tmp = $_FILES['files']['tmp_name'][$i];
                    $file_type = $_FILES['files']['type'][$i];
                    $file_size = $_FILES['files']['size'][$i];
                    $file = $path . $file_name;

                    if (empty($errors)) {
       
                        // delete image
                        $picName = app('db')->table('tbl_picture_master_data')
                        ->where('sub_assy_no', $sub_assy_no)
                        ->where('sub_assy_name', $sub_assy_name)
                        ->get()
                        ->pluck("pic_name")
                        ->last();
                        $filePath = '../uploads/'.$picName;
                        if (is_file($filePath)) {
                            unlink($filePath);
                        }
                     
                        // Update Pic Name and file
                        move_uploaded_file($file_tmp, $file);
                        app('db')->table('tbl_picture_master_data')
                            ->where('sub_assy_no', $sub_assy_no)
                            ->where('sub_assy_name', $sub_assy_name)
                            ->update([
                                'pic_name' => $file_name
                            ]);
                    }
                }
                if ($errors) print_r($errors);
            }
        }
        return $this->json(["data" => $file_name], 200);
    }
}