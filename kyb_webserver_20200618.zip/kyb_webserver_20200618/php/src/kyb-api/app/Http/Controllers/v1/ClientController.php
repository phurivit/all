<?php

namespace App\Http\Controllers\v1;

use App\Services\v1\DebugLogService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class ClientController extends Controller{

    // check $request's sub assy number in database
    public function checkSubAssyNum(Request $request)
    {
        $subAssyNo = $request->input('sub_assy_number');
        $subAssyName = $request->input('sub_assy_name');
        
//        error_log(print_r('checkSubAssyNum1', TRUE)); 
//        error_log(print_r($request->all(), TRUE)); 

        $result = app('db')
            ->table('tbl_picture_master_data')
            ->where('sub_assy_no', $subAssyNo)
            ->where('sub_assy_name', $subAssyName)
            ->get();
            
//        error_log(print_r($result, TRUE)); 

        if (sizeof($result) > 0) {
            $return = ['complete' => true];
			//For Initial Data. Set [result_scan] to Start , and [code_loc] as timestamp for result_scan in next process 
            $currentDateTime = date("d/m/Y H:i:s");
//            error_log(print_r('checkSubAssyNum3', TRUE)); 
            $insertDetail = [
                "staff_id" => NULL,
                "time_scan" => NULL,
                "sub_assy_no" => NULL,
                "fg_no" =>  NULL,
                "sub_assy_name" =>  NULL,
                "model" =>  NULL,
                "line" =>  NULL,
                "seq_no" =>  NULL,
                "part_no" =>  NULL,
                "part_name" =>  NULL,
                "code_loc" =>  $currentDateTime,
                "qty" =>  NULL,
                "result_scan" => "Start"
            ];
            
            
//            error_log(print_r("$subAssyNo".'_'."$subAssyName".'_detail', TRUE)); 
//            error_log(print_r($insertDetail, TRUE)); 
//            error_log(print_r('checkSubAssyNum4', TRUE)); 
            
            
            app('db')->table("$subAssyNo".'_'."$subAssyName".'_detail')->insert($insertDetail);
            
            
//            error_log(print_r('checkSubAssyNum5', TRUE));
            
                  
            return $this->json(["data" => $return], 200);
        } else {
            $return = ['complete' => false];
            
            
//            error_log(print_r('checkSubAssyNum5', TRUE)); 
            
            return $this->json(["data" => $return], 200);
        }

    }

    public function getDetails(Request $request)
    {
        $subAssyNo = $request->input('sub_assy_number');
        $subAssyName = $request->input('sub_assy_name');

        $csvData = app('db')
            ->table("$subAssyNo".'_'."$subAssyName".'_csv')
            ->select('fg_no as fg_number', 'sub_assy_no as sub_assy_number', 'seq_no')
            ->where('sub_assy_no', $subAssyNo)
            ->where('sub_assy_name', $subAssyName)
            ->orderBy('seq_no', 'asc')
            ->first();

        $maxSeqNum = app('db')->table("$subAssyNo".'_'."$subAssyName".'_csv')
            ->where('sub_assy_no', $subAssyNo)
            ->where('sub_assy_name', $subAssyName)
            ->orderBy('seq_no', 'asc')
            ->get()
            ->pluck('seq_no')
            ->last();

        if (sizeof($csvData) > 0) {
            // get picture name
            $picName = app('db')->table('tbl_picture_master_data')
                ->where('sub_assy_name', $subAssyName)
                ->where('fg_no', $csvData->fg_number)
                ->get()
                ->pluck("pic_name")
                ->last();
            
            $result = [
                "img_src" => $picName,
                "sub_assy_number" => $csvData->sub_assy_number,
                "fg_number" => $csvData->fg_number,
                "seq_no" => $maxSeqNum,
            ];

            return $this->json(["data" => $result], 200);
        } else {
            // return error
            return $this->json(["data" => ["complete" => false]], 200);
        }
    }

    public function getRecentDetails(Request $request)
    {
        $staffId = $request->input('staff_id');
        $subAssyNo = $request->input('sub_assy_number');
        $subAssyName = $request->input('sub_assy_name');
        $fgNo = $request->input('fg_number');

		//Check Initial State? if initail state then no data for use
        $CheckStart = app('db')
            ->table("$subAssyNo".'_'."$subAssyName".'_detail')
            ->get()
            ->pluck('result_scan')
            ->last();
        if($CheckStart != "Start"){
            return $this->json(["data" => ["complete" => true]], 200);
        }


        //Get Keywork for filter target data(Present period)
        $TargetData = app('db')
            ->table("$subAssyNo".'_'."$subAssyName".'_detail')
            ->where('result_scan', 'Start')
            ->get()
            ->pluck('code_loc') //Sign for get target data (Present seq)
            ->last();

        $detailData = app('db')
            ->table("$subAssyNo".'_'."$subAssyName".'_detail')
            ->select('part_no as part_number', 'code_loc', 'part_name', 'qty', 'seq_no')
            ->where('staff_id', $staffId)
            ->where('sub_assy_no', $subAssyNo)
            ->where('sub_assy_name', $subAssyName)
            ->where('fg_no', $fgNo)
            ->where('result_scan', "OK_".$TargetData)
            ->orderBy('seq_no', 'asc')
            ->get()
            ->last();

            // respond data if get data query
        if (isset($detailData)) {
            $detailData->complete = true;
            return $this->json(["data" => $detailData], 200);
        } else {
            return $this->json(["data" => ["complete" => true]], 200);
        }
    }

    public function checkState(Request $request)
    {
        $staffId = $request->input('staff_id');
        $subAssyNo = $request->input('sub_assy_number');
        $subAssyName = $request->input('sub_assy_name');
        $fgNo = $request->input('fg_number');

		// No use summary database for detect
        //$resultSummary = app('db')
        //    ->table("$subAssyNo".'_'."$subAssyName".'_summary')
        //    ->get();

        //if (sizeof($resultSummary) > 0) {
        //    $return = ['complete' => 'finish'];

        //    return $this->json(["data" => $return], 200);
        //}

        $detailData = app('db')
            ->table("$subAssyNo".'_'."$subAssyName".'_detail')
            ->select('part_no as part_number', 'code_loc', 'part_name', 'qty', 'seq_no', 'result_scan')
//*********Data Same Info */
//            ->where('staff_id', $staffId)
//            ->where('sub_assy_no', $subAssyNo)
//            ->where('sub_assy_name', $subAssyName)
//            ->where('fg_no', $fgNo)
            ->get()
            ->last();

        //Get Keywork for filter target data(Present period)
        $TargetData = app('db')
        ->table("$subAssyNo".'_'."$subAssyName".'_detail')
        ->where('result_scan', 'Start')
        ->get()
        ->pluck('code_loc') //Sign for get target data (Present seq)
        ->last();
        
        
//        error_log(print_r($TargetData, TRUE)); 
//        error_log(print_r($detailData, TRUE));  
        
         
        if ($detailData->result_scan != "Start" && isset($detailData)) { //Add Check intial state
            if ($detailData->result_scan == "OK_".$TargetData) {
                $detailData->complete = true;
                return $this->json(["data" => $detailData], 200);
            } else {
                $error = [
                    "complete" => false
                ];
                if (strpos(strtolower($detailData->result_scan), 'seq')) {
                    $error['desc'] = 'seq';
                } else if (strpos(strtolower($detailData->result_scan), 'part')) {
                    $error['desc'] = 'part';
                }
                return $this->json(["data" => $error], 200);
            }
        } else {
            // return false if not get data
            return $this->json(["data" => ["complete" => true]], 200);
        }
    }

    public function submitPartNumber(Request $request)
    {
        $staffId = $request->input('staff_id');
        $subAssyNo = $request->input('sub_assy_number');
        $subAssyName = $request->input('sub_assy_name');
        $fgNo = $request->input('fg_number');
        $partNo = $request->input('part_number');

        $itemMaster = app('db')->table("$subAssyNo".'_'."$subAssyName".'_csv')
            ->where('fg_no', $fgNo)
            ->where('part_no', $partNo)
            ->where('sub_assy_no', $subAssyNo)
            ->where('sub_assy_name', $subAssyName)
            ->orderBy('seq_no', 'asc')
            ->get();

        $maxSeqNum = app('db')->table("$subAssyNo".'_'."$subAssyName".'_csv')
            ->where('sub_assy_no', $subAssyNo)
            ->where('sub_assy_name', $subAssyName)
            ->orderBy('seq_no', 'asc')
            ->get()
            ->pluck('seq_no')
            ->last();

        //Check Initial State?
        $TargetData = app('db')
            ->table("$subAssyNo".'_'."$subAssyName".'_detail')
            ->where('result_scan', 'Start')
            ->get()
            ->pluck('code_loc') //Sign for get target data (Present seq)
            ->last();
       

        $lastSeqNoSubmit = app('db')->table("$subAssyNo".'_'."$subAssyName".'_detail')
            ->where('staff_id', $staffId)
            ->where('sub_assy_no', $subAssyNo)
            ->where('sub_assy_name', $subAssyName)
            ->where('result_scan', "OK_".$TargetData)
            ->orderBy('seq_no', 'asc')
            ->get()
            ->pluck('seq_no')
            ->last();
            
//        error_log(print_r( $itemMaster, TRUE)); 
//        error_log(print_r( $lastSeqNoSubmit, TRUE)); 
        
        // Check Are there part_no more than 1 ?
        if (sizeof($itemMaster) > 1) {
            $itemMaster_array = json_decode(json_encode($itemMaster), true);
            $seqItemMaster = array_column($itemMaster_array, 'seq_no');
            $indexLastSeq = array_search($lastSeqNoSubmit+1, $seqItemMaster);
            
            $itemMaster = $itemMaster[$indexLastSeq];
        } else if (sizeof($itemMaster) == 1) {
            $itemMaster = $itemMaster[0];
        }
        
        if(!isset($lastSeqNoSubmit)) {
            $lastSeqNoSubmit = 0;
        }
        

//        error_log(print_r("submitPartNumber1", TRUE)); 
        //error_log(print_r($itemMaster->seq_no, TRUE));  
        //error_log(print_r($lastSeqNoSubmit, TRUE));
//        error_log(print_r(sizeof($itemMaster), TRUE));
        
        
        $currentDateTime = date("d/m/Y H:i:s");

        if (sizeof($itemMaster) > 0 && ($lastSeqNoSubmit+1 == $itemMaster->seq_no)) {

            $insertDetail = [
                "staff_id" => $request->input('staff_id'),
                "time_scan" => $currentDateTime,
                "sub_assy_no" => $itemMaster->sub_assy_no,
                "fg_no" =>  $itemMaster->fg_no,
                "sub_assy_name" =>  $itemMaster->sub_assy_name,
                "model" =>  $itemMaster->model,
                "line" =>  $itemMaster->line,
                "seq_no" =>  $itemMaster->seq_no,
                "part_no" =>  $itemMaster->part_no,
                "part_name" =>  $itemMaster->part_name,
                "code_loc" =>  $itemMaster->code_loc,
                "qty" =>  $itemMaster->qty,
                "result_scan" => "OK_".$TargetData
            ];
            
            
//            error_log(print_r("submitPartNumber2", TRUE));
            
            
            app('db')->table("$subAssyNo".'_'."$subAssyName".'_detail')
                ->insert($insertDetail);
                
                
//            error_log(print_r("submitPartNumber3", TRUE));
 
            
            
            $result = [
                "part_number" =>  $itemMaster->part_no,
                "code_loc" =>  $itemMaster->code_loc,
                "part_name" =>  $itemMaster->part_name,
                "qty" =>  $itemMaster->qty,
                "seq_no" =>  $itemMaster->seq_no,
            ];

            if ($itemMaster->seq_no < $maxSeqNum) {
                $result['complete'] = true;
            } else if ($itemMaster->seq_no == $maxSeqNum) { //Case: Last Seq, Set Info to summary Database
                $insertSummary = [
                    "staff_id" => $request->input('staff_id'),
                    "time_scan" => $currentDateTime,
                    "sub_assy_no" => $itemMaster->sub_assy_no,
                    "fg_no" =>  $itemMaster->fg_no,
                    "sub_assy_name" =>  $itemMaster->sub_assy_name,
                    "model" =>  $itemMaster->model,
                    "line" =>  $itemMaster->line,
                    "status" => "OK_".$TargetData
                ];

//                error_log(print_r("submitPartNumber4", TRUE));

                app('db')->table("$subAssyNo".'_'."$subAssyName".'_summary')
                    ->insert($insertSummary);

//                error_log(print_r("submitPartNumber5", TRUE));

                $result['complete'] = 'success';
            }

            return $this->json(["data" => $result], 200);
        } else {
//            error_log(print_r("submitPartNumber6", TRUE));
            $error = [
                "complete" => false
            ];
            if (sizeof($itemMaster) == 0) {
                $insertDetail = [
                    "staff_id" => $staffId,
                    "time_scan" => $currentDateTime,
                    "sub_assy_no" => NULL,
                    "fg_no" =>  NULL,
                    "sub_assy_name" =>  NULL,
                    "model" =>  NULL,
                    "line" =>  NULL,
                    "seq_no" =>  NULL,
                    "part_no" =>  $partNo,
                    "part_name" =>  NULL,
                    "code_loc" =>  NULL,
                    "qty" =>  NULL,
                    "result_scan" => "Wrong part number"
                ];

                $error['desc'] = 'part';
            } else {
                $insertDetail = [
                    "staff_id" => $request->input('staff_id'),
                    "time_scan" => $currentDateTime,
                    "sub_assy_no" => $itemMaster->sub_assy_no,
                    "fg_no" =>  $itemMaster->fg_no,
                    "sub_assy_name" =>  $itemMaster->sub_assy_name,
                    "model" =>  $itemMaster->model,
                    "line" =>  $itemMaster->line,
                    "seq_no" =>  $itemMaster->seq_no,
                    "part_no" =>  $itemMaster->part_no,
                    "part_name" =>  $itemMaster->part_name,
                    "code_loc" =>  $itemMaster->code_loc,
                    "qty" =>  $itemMaster->qty,
                    "result_scan" => "Wrong Seq.no"
                ];

                $error['desc'] = 'seq';
            }


//            error_log(print_r("submitPartNumber7", TRUE));

            app('db')->table("$subAssyNo".'_'."$subAssyName".'_detail')
            ->insert($insertDetail);

//            error_log(print_r("submitPartNumber8", TRUE));
            return $this->json(["data" => $error], 200);
        }
    }
}