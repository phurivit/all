<?php

namespace App\Http\Controllers;

use Laravel\Lumen\Routing\Controller as BaseController;

class Controller extends BaseController
{
    public function success($message, $code=200) {
        return response()->json(['message' => $message], $code);
    }

    public function json($data, $code=200) {
        return response()->json($data, $code);
    }
    
    public function json_utf8($data, $code=200) {
        return response()->json(
            ["data" => $data],
            $code,
            [
                'Content-Type' => 'application/json;charset=UTF-8',
                'Charset' => 'utf-8'
            ],
            JSON_UNESCAPED_UNICODE
        );
    }

    public function error($message, $code=200) {
        return response()->json(['error' => $message], $code);
    }
}
