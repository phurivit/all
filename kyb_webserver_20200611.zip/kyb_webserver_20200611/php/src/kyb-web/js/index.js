window.onload = function() {
    getIP();
}

function getIP() { 
    hostname = window.location.hostname;
    hostnamePort = hostname+':7777';
    localStorage.setItem('hostname', hostnamePort);
//     hostname = window.location.origin;
//     splitPath = window.location.pathname.split("/");
//     pathFolder = hostname+'/'+splitPath[1];
//    $.ajax({
//         url : pathFolder+'/getIP.php',
//         type : 'get',
//         success : function (result) {
//             console.log ('result', result); // Here, you need to use response by PHP file.
//             hostnamePort = result+':7777';
//             localStorage.setItem('hostname', hostnamePort);
//         },
//         error : function (result) {
//             console.log (result);
//         }
//     })
}