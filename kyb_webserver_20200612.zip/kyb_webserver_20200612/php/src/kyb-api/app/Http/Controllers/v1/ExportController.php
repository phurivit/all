<?php

namespace App\Http\Controllers\v1;

use App\Services\v1\DebugLogService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class ExportController extends Controller{

    public function queryPicMasterList ()
    {
        $result = app('db')->table('tbl_picture_master_data')
            ->get();

        return $result;
    }

    public function getPicMasterList ()
    {
        $result = $this->queryPicMasterList();

        return $this->json(["data" => $result], 200);
    }

    public function getHistoryDetail(Request $request)
    {
        $data = $request->all();
        $subAssyNo = $data[0];
        $subAssyName = $data[1];

        $result = app('db')->table("$subAssyNo".'_'."$subAssyName".'_detail')
            ->get();

        return $this->json(["data" => $result], 200);
    }

    public function getHistorySummary(Request $request)
    {
        $data = $request->all();
        $subAssyNo = $data[0];
        $subAssyName = $data[1];

        $result = app('db')->table("$subAssyNo".'_'."$subAssyName".'_summary')
            ->get();

        return $this->json(["data" => $result], 200);
    }
}