//* connect api
function httpConnect (type, IPAddress, pathURL, data, callbackSuccess, callbackError) {
    if(localStorage.getItem('hostname')) {
        IPAddress = localStorage.getItem('hostname');
    }
    $.ajax({
        url: 'http://'+ IPAddress +'/api/v1/'+ pathURL,
        type: type,
        data: data,
        async: false,
        dataType: "json",
        timeout: 5000,
        success: function(result) {
            callbackSuccess(result);
        },
        error: function(result) {
            callbackError();
        }
    })
}